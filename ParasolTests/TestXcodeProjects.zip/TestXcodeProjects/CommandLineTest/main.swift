//
//  main.swift
//  CommandLineTest
//
//  Created by Kyle McAlpine on 30/01/2016.
//  Copyright © 2016 Loot Financial Services Ltd. All rights reserved.
//

import Foundation

print("Hello, World!")

